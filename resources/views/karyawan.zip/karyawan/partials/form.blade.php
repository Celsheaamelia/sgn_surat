@php $k = $karyawan ?? null; @endphp

<div class="row g-3 mb-3">
    <div class="col-md-4">
        <label class="form-label">NIK <span class="ledger-required">*</span></label>
        <input type="text" name="nik" class="form-control" required value="{{ old('nik', $k->nik ?? '') }}">
    </div>
    <div class="col-md-8">
        <label class="form-label">Nama Lengkap <span class="ledger-required">*</span></label>
        <input type="text" name="nama" class="form-control" required value="{{ old('nama', $k->nama ?? '') }}">
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-6">
        <label class="form-label">Jabatan</label>
        <input type="text" name="jabatan" class="form-control" value="{{ old('jabatan', $k->jabatan ?? '') }}">
    </div>
    <div class="col-md-6">
        <label class="form-label">Departemen</label>
        <input type="text" name="departemen" class="form-control" value="{{ old('departemen', $k->departemen ?? '') }}">
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-5">
        <label class="form-label">Tempat Lahir</label>
        <input type="text" name="tempat_lahir" class="form-control" value="{{ old('tempat_lahir', $k->tempat_lahir ?? '') }}">
    </div>
    <div class="col-md-4">
        <label class="form-label">Tanggal Lahir</label>
        <input type="date" name="tanggal_lahir" class="form-control"
               value="{{ old('tanggal_lahir', optional($k?->tanggal_lahir)->format('Y-m-d')) }}">
    </div>
    <div class="col-md-3">
        <label class="form-label">Jenis Kelamin</label>
        <select name="jenis_kelamin" class="form-select">
            <option value="">-</option>
            <option value="Laki-laki" @selected(old('jenis_kelamin', $k->jenis_kelamin ?? '') === 'Laki-laki')>Laki-laki</option>
            <option value="Perempuan" @selected(old('jenis_kelamin', $k->jenis_kelamin ?? '') === 'Perempuan')>Perempuan</option>
        </select>
    </div>
</div>

<div class="mb-3">
    <label class="form-label">Alamat</label>
    <textarea name="alamat" rows="2" class="form-control">{{ old('alamat', $k->alamat ?? '') }}</textarea>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-6">
        <label class="form-label">No. HP</label>
        <input type="text" name="no_hp" class="form-control" value="{{ old('no_hp', $k->no_hp ?? '') }}">
    </div>
    <div class="col-md-6">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" value="{{ old('email', $k->email ?? '') }}">
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-6">
        <label class="form-label">Tanggal Mulai Kerja</label>
        <input type="date" name="tanggal_mulai_kerja" class="form-control"
               value="{{ old('tanggal_mulai_kerja', optional($k?->tanggal_mulai_kerja)->format('Y-m-d')) }}">
    </div>
    <div class="col-md-6">
        <label class="form-label">Status Karyawan</label>
        <select name="status_karyawan" class="form-select">
            <option value="Aktif" @selected(old('status_karyawan', $k->status_karyawan ?? 'Aktif') === 'Aktif')>Aktif</option>
            <option value="Nonaktif" @selected(old('status_karyawan', $k->status_karyawan ?? '') === 'Nonaktif')>Nonaktif</option>
        </select>
    </div>
</div>

<div class="d-flex align-items-center justify-content-end gap-3">
    <a href="{{ route('karyawan.index') }}" class="btn ledger-btn-ghost">Batal</a>
    <button type="submit" class="btn ledger-btn-brass">
        <i class="bi bi-save me-1"></i> Simpan
    </button>
</div>
