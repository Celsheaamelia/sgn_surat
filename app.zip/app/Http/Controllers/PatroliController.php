<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\PatrolCheckpoint;
use App\Models\PatrolScan;
use App\Models\PatrolSession;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class PatroliController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        $sesi = PatrolSession::with(['scans.checkpoint'])
            ->where('user_id', $user->id)
            ->hariIni()
            ->latest('mulai_at')
            ->first();

        $checkpoints = PatrolCheckpoint::aktif()->urut()->get();

        $scanByCheckpoint = $sesi
            ? $sesi->scans->keyBy('patrol_checkpoint_id')
            : collect();

        return view('patroli.satpam.index', [
            'sesi'             => $sesi,
            'checkpoints'      => $checkpoints,
            'scanByCheckpoint' => $scanByCheckpoint,
        ]);
    }

    /**
     * Mulai shift patroli baru untuk hari ini.
     */
    public function start()
    {
        $user = Auth::user();

        $sesiBerjalan = PatrolSession::where('user_id', $user->id)
            ->berjalan()
            ->hariIni()
            ->first();

        if ($sesiBerjalan) {
            return redirect()->route('patroli.index')
                ->with('info', 'Anda sudah memiliki shift patroli yang sedang berjalan.');
        }

        PatrolSession::create([
            'user_id'          => $user->id,
            'tanggal'          => now()->toDateString(),
            'mulai_at'         => now(),
            'status'           => 'berjalan',
            'total_checkpoint' => PatrolCheckpoint::aktif()->count(),
        ]);

        return redirect()->route('patroli.index')
            ->with('success', 'Shift patroli dimulai. Silakan scan titik pertama.');
    }

    /**
     * Form input hasil scan untuk satu titik (dibuka setelah QR di-scan atau dipilih manual).
     */
    public function scanForm(string $kode)
    {
        $checkpoint = PatrolCheckpoint::aktif()->where('kode', $kode)->firstOrFail();

        $sesi = $this->sesiAktifOrFail();

        $sudahScan = PatrolScan::where('patrol_session_id', $sesi->id)
            ->where('patrol_checkpoint_id', $checkpoint->id)
            ->first();

        if ($sudahScan) {
            return redirect()->route('patroli.index')
                ->with('info', "Titik {$checkpoint->nama_titik} sudah dicatat pada shift ini.");
        }

        return view('patroli.satpam.scan', [
            'checkpoint' => $checkpoint,
            'sesi'       => $sesi,
        ]);
    }

    /**
     * Simpan hasil scan/laporan untuk satu titik.
     */
    public function store(Request $request, string $kode)
{
    $checkpoint = PatrolCheckpoint::aktif()->where('kode', $kode)->firstOrFail();
    $sesi = $this->sesiAktifOrFail();

    $sudahScan = PatrolScan::where('patrol_session_id', $sesi->id)
        ->where('patrol_checkpoint_id', $checkpoint->id)
        ->exists();

    if ($sudahScan) {
        return redirect()->route('patroli.index')
            ->with('info', "Titik {$checkpoint->nama_titik} sudah dicatat pada shift ini.");
    }

    $data = $request->validate([
        'status'    => ['required', Rule::in(['aman', 'temuan', 'bahaya'])],
        'catatan'   => ['nullable', 'string', 'max:1000'],
        // Foto wajib kalau status bukan "aman", sesuai SOP: "Upload bukti" untuk temuan
        'foto'      => [Rule::requiredIf(fn () => $request->status !== 'aman'), 'nullable', 'image', 'max:5120'],
        'latitude'  => ['nullable', 'numeric'],
        'longitude' => ['nullable', 'numeric'],
    ], [
        'foto.required_if' => 'Foto bukti wajib diupload untuk laporan temuan/potensi bahaya.',
    ]);

    if ($request->hasFile('foto')) {
        $data['foto'] = $request->file('foto')->store('patroli-scan', 'public');
    }

    $scan = PatrolScan::create([
        'patrol_session_id'    => $sesi->id,
        'patrol_checkpoint_id' => $checkpoint->id,
        'status'               => $data['status'],
        'catatan'              => $data['catatan'] ?? null,
        'foto'                 => $data['foto'] ?? null,
        'latitude'             => $data['latitude'] ?? null,
        'longitude'            => $data['longitude'] ?? null,
        'scanned_at'           => now(),
    ]);

    if (in_array($data['status'], ['temuan', 'bahaya'], true)) {
        $scan->load('checkpoint', 'session.user');

        $supervisors = \App\Models\User::whereIn('role', [
            \App\Models\User::ROLE_ADMIN,
            \App\Models\User::ROLE_SUPERVISOR,
        ])->get();

        \Illuminate\Support\Facades\Notification::send(
            $supervisors,
            new \App\Notifications\TemuanPatroliDitemukan($scan)
        );
    }

    $pesan = $data['status'] === 'aman'
        ? "Titik {$checkpoint->nama_titik} tercatat aman."
        : "Laporan untuk {$checkpoint->nama_titik} terkirim, supervisor akan diberi notifikasi.";

    return redirect()->route('patroli.index')->with('success', $pesan);
}

    /**
     * Tutup shift patroli hari ini.
     */
    public function finish()
    {
        $sesi = $this->sesiAktifOrFail();

        $sesi->update([
            'selesai_at' => now(),
            'status'     => 'selesai',
        ]);

        return redirect()->route('patroli.index')
            ->with('success', 'Patroli selesai. Terima kasih, hasil sudah dikirim ke sistem.');
    }

    /**
     * Riwayat shift milik petugas yang sedang login.
     */
    public function riwayat(Request $request)
    {
        $sesiList = PatrolSession::with('user')
            ->where('user_id', Auth::id())
            ->when($request->tanggal, fn ($q) => $q->whereDate('tanggal', $request->tanggal))
            ->orderByDesc('tanggal')
            ->orderByDesc('mulai_at')
            ->paginate(10)
            ->withQueryString();

        return view('patroli.satpam.riwayat', compact('sesiList'));
    }

    /**
     * Detail satu shift milik petugas sendiri (read-only).
     */
    public function riwayatShow(PatrolSession $sesi)
    {
        abort_unless($sesi->user_id === Auth::id(), 403);

        $sesi->load(['scans.checkpoint', 'user']);

        return view('patroli.session-detail', [
            'sesi'    => $sesi,
            'isAdmin' => false,
        ]);
    }

    private function sesiAktifOrFail(): PatrolSession
    {
        $sesi = PatrolSession::where('user_id', Auth::id())->berjalan()->hariIni()->first();

        abort_if(! $sesi, 400, 'Anda belum memulai shift patroli hari ini.');

        return $sesi;
    }
}
