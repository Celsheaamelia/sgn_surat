@extends('layouts.app')

@section('content')
@include('patroli._styles')

<div class="patroli-page">
    <div class="container-fluid py-1 py-md-2">

        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
            <div>
                <div class="patroli-eyebrow mb-1">Patroli Digital</div>
                <h2 class="patroli-title mb-1" style="font-size: 1.6rem;">Halo, {{ auth()->user()->username }} 👋</h2>
                <p class="patroli-subtitle mb-0">{{ now()->translatedFormat('l, d F Y') }}</p>
            </div>
            <a href="{{ route('patroli.riwayat') }}" class="btn patroli-btn-ghost">
                <i class="bi bi-clock-history me-1"></i> Riwayat Shift Saya
            </a>
        </div>

        @if (session('success'))
            <div class="patroli-alert-success mb-3">{{ session('success') }}</div>
        @endif
        @if (session('info'))
            <div class="patroli-alert-info mb-3">{{ session('info') }}</div>
        @endif
        @if (session('error'))
            <div class="patroli-alert-danger mb-3">{{ session('error') }}</div>
        @endif

        @php
            $totalCheckpoint = $checkpoints->count();
            $sudahScan = $scanByCheckpoint->count();
            $progres = $totalCheckpoint > 0 ? round(($sudahScan / $totalCheckpoint) * 100) : 0;
        @endphp

        {{-- ===== Hero: status shift ===== --}}
        <div class="patroli-hero mb-4">
            @if ($sesi)
                <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 position-relative">
                    <div>
                        <span class="patroli-pill berjalan mb-2">
                            <i class="bi bi-shield-check"></i> Shift sedang berjalan
                        </span>
                        <div class="patroli-hero-muted">Mulai pukul {{ $sesi->mulai_at->format('H:i') }}</div>
                    </div>
                    <form action="{{ route('patroli.finish') }}" method="POST"
                          onsubmit="return confirm('Yakin ingin menyelesaikan shift patroli sekarang?');">
                        @csrf
                        <button type="submit" class="btn patroli-btn-light">
                            <i class="bi bi-flag"></i> Selesaikan Patroli
                        </button>
                    </form>
                </div>

                <div class="mt-4 position-relative">
                    <div class="d-flex justify-content-between mb-2" style="font-size: 0.85rem;">
                        <span class="patroli-hero-muted">Progres titik checkpoint</span>
                        <strong>{{ $sudahScan }} / {{ $totalCheckpoint }}</strong>
                    </div>
                    <div class="patroli-progress" style="background: rgba(255,255,255,0.18); height: 10px;">
                        <div class="bar" style="width: {{ $progres }}%; background: linear-gradient(90deg, #6ee7b7, #34d399);"></div>
                    </div>
                </div>
            @else
                <div class="text-center py-3 position-relative">
                    <i class="bi bi-shield-lock" style="font-size: 2.6rem; color: rgba(240,253,244,0.55);"></i>
                    <p class="mt-3 mb-3 patroli-hero-muted">Anda belum memulai shift patroli hari ini.</p>
                    <form action="{{ route('patroli.start') }}" method="POST">
                        @csrf
                        <button type="submit" class="btn patroli-btn-brass px-4">
                            <i class="bi bi-play-fill"></i> Mulai Patroli
                        </button>
                    </form>
                </div>
            @endif
        </div>

        {{-- ===== Daftar titik checkpoint ===== --}}
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="patroli-title mb-0" style="font-size: 1.15rem;">Titik Checkpoint</h5>
            @if ($totalCheckpoint > 0)
                <span class="patroli-subtitle">{{ $sudahScan }} dari {{ $totalCheckpoint }} titik tercatat</span>
            @endif
        </div>

        @if ($checkpoints->isEmpty())
            <div class="patroli-empty">
                <i class="bi bi-geo-alt d-block mb-2"></i>
                Belum ada titik checkpoint aktif. Hubungi admin.
            </div>
        @else
            <div class="row g-3">
                @foreach ($checkpoints as $cp)
                    @php
                        $scan = $scanByCheckpoint->get($cp->id);
                        $statusInfo = match ($scan?->status) {
                            'aman'   => ['label' => 'Aman', 'class' => 'aman', 'icon' => 'bi-check-circle'],
                            'temuan' => ['label' => 'Temuan', 'class' => 'temuan', 'icon' => 'bi-exclamation-triangle'],
                            'bahaya' => ['label' => 'Bahaya', 'class' => 'bahaya', 'icon' => 'bi-exclamation-octagon'],
                            default  => ['label' => 'Belum discan', 'class' => 'kosong', 'icon' => 'bi-dash-circle'],
                        };
                        $tileClass = $scan ? 'st-' . $scan->status : '';
                    @endphp
                    <div class="col-md-4 col-sm-6">
                        <div class="patroli-cp-tile h-100 {{ $tileClass }}">
                            <div class="card-body d-flex flex-column h-100">
                                <div class="d-flex justify-content-between align-items-start mb-2 gap-2">
                                    <h6 class="mb-0 fw-semibold">{{ $cp->nama_titik }}</h6>
                                    <span class="patroli-pill {{ $statusInfo['class'] }}">
                                        <i class="bi {{ $statusInfo['icon'] }}"></i> {{ $statusInfo['label'] }}
                                    </span>
                                </div>
                                @if ($cp->area)
                                    <div class="patroli-subtitle mb-1"><i class="bi bi-geo-alt"></i> {{ $cp->area }}</div>
                                @endif
                                <div class="patroli-subtitle mb-3" style="font-family: 'IBM Plex Mono', monospace; font-size: 0.78rem;">
                                    {{ $cp->kode }}
                                </div>

                                <div class="mt-auto">
                                    @if (! $sesi)
                                        <button class="btn patroli-btn-ghost w-100" disabled>
                                            Mulai shift dulu
                                        </button>
                                    @elseif ($scan)
                                        <button class="btn patroli-btn-ghost w-100" disabled>
                                            <i class="bi bi-check2"></i> Dicatat {{ $scan->scanned_at->format('H:i') }}
                                        </button>
                                    @else
                                        <a href="{{ route('patroli.scan.form', $cp->kode) }}" class="btn patroli-btn-brass w-100">
                                            <i class="bi bi-qr-code-scan"></i> Scan Titik Ini
                                        </a>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif

    </div>
</div>
@endsection
