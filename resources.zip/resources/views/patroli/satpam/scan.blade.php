@extends('layouts.app')

@section('content')
@include('patroli._styles')

<div class="patroli-page">
    <div class="container-fluid py-1 py-md-2" style="max-width: 640px;">

        <div class="d-flex align-items-center mb-3">
            <a href="{{ route('patroli.index') }}" class="btn patroli-btn-icon me-2">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <div class="patroli-eyebrow mb-1">Scan Titik</div>
                <h5 class="patroli-title mb-0">{{ $checkpoint->nama_titik }}</h5>
                <small class="patroli-subtitle">
                    {{ $checkpoint->kode }} @if($checkpoint->area) &middot; {{ $checkpoint->area }} @endif
                </small>
            </div>
        </div>

        <div class="patroli-card">
            <div class="card-body patroli-form-section">
                <form action="{{ route('patroli.scan.store', $checkpoint->kode) }}" method="POST" enctype="multipart/form-data" id="scanForm">
                    @csrf

                    <label class="form-label d-block mb-2">Kondisi Titik</label>
                    <div class="row g-2 mb-3 patroli-status-pick">
                        <div class="col-4">
                            <input type="radio" name="status" id="status_aman" value="aman"
                                   {{ old('status', 'aman') === 'aman' ? 'checked' : '' }}>
                            <label for="status_aman">
                                <i class="bi bi-check-circle"></i> Aman
                            </label>
                        </div>
                        <div class="col-4">
                            <input type="radio" name="status" id="status_temuan" value="temuan"
                                   {{ old('status') === 'temuan' ? 'checked' : '' }}>
                            <label for="status_temuan">
                                <i class="bi bi-exclamation-triangle"></i> Temuan
                            </label>
                        </div>
                        <div class="col-4">
                            <input type="radio" name="status" id="status_bahaya" value="bahaya"
                                   {{ old('status') === 'bahaya' ? 'checked' : '' }}>
                            <label for="status_bahaya">
                                <i class="bi bi-exclamation-octagon"></i> Bahaya
                            </label>
                        </div>
                    </div>
                    @error('status')
                        <div class="text-danger small mb-3">{{ $message }}</div>
                    @enderror

                    <div class="mb-3">
                        <label for="catatan" class="form-label">
                            Catatan <span id="catatanOptional" class="text-muted fw-normal">(opsional)</span>
                        </label>
                        <textarea name="catatan" id="catatan" rows="3" maxlength="1000"
                                  class="form-control @error('catatan') is-invalid @enderror"
                                  placeholder="Jelaskan kondisi di titik ini...">{{ old('catatan') }}</textarea>
                        @error('catatan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="foto" class="form-label">
                            Foto Bukti
                            <span id="fotoRequiredLabel" class="text-danger fw-normal d-none">*wajib untuk temuan/bahaya</span>
                        </label>
                        <input type="file" name="foto" id="foto" accept="image/*" capture="environment"
                               class="form-control @error('foto') is-invalid @enderror">
                        @error('foto')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                        <div id="fotoPreviewWrap" class="mt-2 d-none">
                            <img id="fotoPreview" src="#" alt="Preview" class="img-fluid rounded border" style="max-height: 220px;">
                        </div>
                    </div>

                    <input type="hidden" name="latitude" id="latitude" value="{{ old('latitude') }}">
                    <input type="hidden" name="longitude" id="longitude" value="{{ old('longitude') }}">
                    <div id="lokasiInfo" class="patroli-subtitle mb-3">
                        <i class="bi bi-geo-alt"></i> Mengambil lokasi GPS...
                    </div>

                    <button type="submit" class="btn patroli-btn-brass w-100 py-2">
                        <i class="bi bi-send-check"></i> Kirim Laporan
                    </button>
                </form>
            </div>
        </div>

    </div>
</div>

<script>
    // Toggle keterangan wajib foto/catatan sesuai status yang dipilih
    const radios = document.querySelectorAll('input[name="status"]');
    const fotoRequiredLabel = document.getElementById('fotoRequiredLabel');
    const catatanOptional = document.getElementById('catatanOptional');

    function updateRequirement() {
        const checked = document.querySelector('input[name="status"]:checked');
        const isAman = checked && checked.value === 'aman';
        fotoRequiredLabel.classList.toggle('d-none', isAman);
        catatanOptional.classList.toggle('d-none', !isAman);
    }
    radios.forEach(r => r.addEventListener('change', updateRequirement));
    updateRequirement();

    // Preview foto
    document.getElementById('foto').addEventListener('change', function (e) {
        const file = e.target.files[0];
        const wrap = document.getElementById('fotoPreviewWrap');
        const img = document.getElementById('fotoPreview');
        if (file) {
            img.src = URL.createObjectURL(file);
            wrap.classList.remove('d-none');
        } else {
            wrap.classList.add('d-none');
        }
    });

    // Ambil koordinat GPS (opsional, tidak menghalangi submit kalau gagal/ditolak)
    const lokasiInfo = document.getElementById('lokasiInfo');
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (pos) {
            document.getElementById('latitude').value = pos.coords.latitude;
            document.getElementById('longitude').value = pos.coords.longitude;
            lokasiInfo.innerHTML = '<i class="bi bi-geo-alt-fill text-success"></i> Lokasi berhasil didapat';
        }, function () {
            lokasiInfo.innerHTML = '<i class="bi bi-geo-alt text-muted"></i> Lokasi tidak tersedia, lanjut tanpa GPS';
        }, { timeout: 8000 });
    } else {
        lokasiInfo.innerHTML = '';
    }
</script>
@endsection
